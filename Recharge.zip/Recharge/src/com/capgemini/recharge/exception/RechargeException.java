package com.capgemini.recharge.exception;

public class RechargeException {

	public String ExceptionMsg() {
		StringBuilder sb=new StringBuilder();
		try{
			throw new ArithmeticException("No details found with recharge id");
		}
		catch(Exception e){
			sb.append(e.getMessage());
		}
		return sb.toString();
	}

}
