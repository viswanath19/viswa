package com.capgemini.recharge.dao;

public interface ISqlFinalQueries {
	public static final String displayPlans="select * from rechargeplans";

}
