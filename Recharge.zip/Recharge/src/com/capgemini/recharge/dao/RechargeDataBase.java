package com.capgemini.recharge.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.recharge.bean.RechargeBean;
import com.capgemini.recharge.exception.RechargeException;
import com.capgemini.recharge.util.RechargeDBConnection;
	
public class RechargeDataBase implements IRechargeInterface{  
	Logger logger=Logger.getRootLogger();
	public RechargeDataBase()
	{
	//System.out.println("hello");
	PropertyConfigurator.configure("resources//log4j.properties");
	}
	@Override
	public String displayRechargePlans(){
	//System.out.println("hello");
	String planname = null;
	int amount=0;
	String msg = null;
	StringBuilder sb=new StringBuilder();
	try{  
	//step1 load the driver class  
	Class.forName("oracle.jdbc.driver.OracleDriver");  
	  
	//step2 create  the connection object  
	Connection con=RechargeDBConnection.getConnection();//DriverManager.getConnection(  
	//"jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
	  
	//step3 create the statement object  
	Statement stmt=con.createStatement();  
	  
	//step4 execute query  
	ResultSet rs=stmt.executeQuery(ISqlFinalQueries.displayPlans);
	//ResultSet rs=stmt.executeQuery("select * from rechargeplans"); 
	if(rs!=null){
		
		while(rs.next()){
			//System.out.println("hrllo");
			
			planname=rs.getString(1);
			amount=rs.getInt(2);
			sb.append(planname+"            "+Integer.toString(amount)+"\n");
			logger.info("details fetched successfully");
			//System.out.println(details);
			
		}
	}
	//step5 close the connection object  
	con.close();  
	  
	}catch(Exception e){ 
		msg=e.getMessage();
	}
	return sb.toString();
	  
	}

	@Override
	public int getAmount(String planname) {
		int amount=0;
		try{  
			//step1 load the driver class  
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con1=RechargeDBConnection.getConnection();//DriverManager.getConnection(  
					//"jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con1.createStatement();  
			  
			//step4 execute query  
			ResultSet rs=stmt.executeQuery("select amount from rechargeplans where planename='"+planname+"'"); 
			if(rs!=null){
				while(rs.next()){
					amount = rs.getInt(1);
					//System.out.println(details);
					
				}
			}
			//step5 close the connection object  
			con1.close();  
			  
			}catch(Exception e){ 
				String msg = e.getMessage();
			}
		return amount;
	}
	@Override
	public long addUserDetails(String name,long mobile,String status,String planName,int amount) throws SQLException, IOException {
		Connection conn=RechargeDBConnection.getConnection();//DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");
		String s1="insert into rechargeInfo values(?,?,?,?,?,?)";
		PreparedStatement s=conn.prepareStatement(s1);
		String s2="select rec_seq.nextval from dual";
		java.sql.Statement sw=conn.createStatement();
		ResultSet r1=sw.executeQuery(s2);
		int val=0;
		while(r1.next())
		{
			val=r1.getInt(1);
		}
		//s.executeUpdate();
		s=conn.prepareStatement(s1);
		s.setInt(1,val);
		s.setString(2,name);
		s.setLong(3, mobile);
		s.setString(4,status);
		s.setString(5,planName);
		s.setInt(6,amount);
		s.executeUpdate();
		return val;
	}
	@Override
	public String getRechargeDetails(long rechId,RechargeBean rb) {
		String planname = null;
		int amount=0;
		String name=null;
		String status=null;
		long mobileno=0;
		long rechid=0;
		String exceptionmsg=null;
		StringBuilder sb=new StringBuilder();
		try{  
			//step1 load the driver class  
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con1=RechargeDBConnection.getConnection();//DriverManager.getConnection(  
			//"jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con1.createStatement();  
			  
			//step4 execute query  
			ResultSet rs=stmt.executeQuery("select * from rechargeInfo where rechid='"+rechId+"'"); 
			if(rs!=null){
				while(rs.next()){
					rechid=rs.getLong(1);
					name=rs.getString(2);
					mobileno=rs.getLong(3);
					status=rs.getString(4);
					planname=rs.getString(5);
					amount=rs.getInt(6);
					sb.append(rechid+"      "+name+"      "+mobileno+"          "+status+"        "+planname+"            "+Integer.toString(amount)+"\n");
					//System.out.println(details);
					
				}
			}
			if(rechid==0){
				//System.out.println("hello");
				RechargeException re=new RechargeException();
				exceptionmsg=re.ExceptionMsg();
				//System.out.println(exceptionmsg);
				sb.append(exceptionmsg);
			}
				//throw new ArithmeticException("No details found with recharge id "+rechId);  }
			else{
			rb.setRechid(rechId);
			rb.setName(name);
			rb.setAmount(amount);
			rb.setMobileno(mobileno);
			rb.setStatus(status);
			rb.setPlanname(planname);
			System.out.println(rb.getName());
			}
			//step5 close the connection object  
			con1.close();  
			  
			}catch(Exception e){ 
				//System.out.println("hello");
				//sb.append(exceptionmsg);
			}
		return sb.toString();
	}

}

