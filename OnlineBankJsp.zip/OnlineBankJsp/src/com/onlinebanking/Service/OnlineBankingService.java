package com.onlinebanking.Service;

import java.util.ArrayList;

import Exception.OnlineBankingException;

import com.onlinebanking.Bean.OnlineBankingBean;
import com.onlinebanking.Dao.IonlineBankingDao;
import com.onlinebanking.Dao.OnlineBankingDao;

public class OnlineBankingService implements IonlineBankingService{

	@Override
	public ArrayList<Long> getAccounts(long acc_no) throws OnlineBankingException {
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<Long> accounts=new ArrayList<Long>();
		accounts=ibd.getAccounts(acc_no);
		return accounts;
	}

	@Override
	public String getEmailId(long accountNo) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		String email=ibd.getEmailId(accountNo);
		return email;
	}

	@Override
	public String updateEmail(long acc_no, String email, String existingemail) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		String updateEmailId=ibd.getEmailId(acc_no,email,existingemail);
		return updateEmailId;
	}

	@Override
	public String getAddress(long accountNo) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		String address=ibd.getAddress(accountNo);
		return address;
	}
	@Override
	public String updateAddress(long acc_no, String address, String existingAddress) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		String updateEmailId=ibd.getAddressUpdate(acc_no,address,existingAddress);
		return updateEmailId;
	}

	@Override
	public String raiseCheckBookRequest(long accountNo, String description) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		String raiseCheckBookRequest=ibd.raiseCheckBookRequest(accountNo,description);
		return raiseCheckBookRequest;
	}

	@Override
	public ArrayList<OnlineBankingBean> getCheckBookService(long service_id) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<OnlineBankingBean> serviceRequestDetails=new ArrayList<OnlineBankingBean>();
		serviceRequestDetails=ibd.getServiceRequestDetails(service_id);
		return serviceRequestDetails;
	}

}
