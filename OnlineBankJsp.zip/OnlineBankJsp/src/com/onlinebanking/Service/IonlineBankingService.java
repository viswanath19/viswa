package com.onlinebanking.Service;

import java.util.ArrayList;

import com.onlinebanking.Bean.OnlineBankingBean;

import Exception.OnlineBankingException;

public interface IonlineBankingService {

	ArrayList<Long> getAccounts(long acc_no) throws OnlineBankingException;

	String getEmailId(long accountNo);

	String updateEmail(long acc_no, String email, String existingemail);

	String getAddress(long accountNo);

	String updateAddress(long acc_no, String address, String existingAddress);

	String raiseCheckBookRequest(long accountNo, String description);

	ArrayList<OnlineBankingBean> getCheckBookService(long service_id);

}
