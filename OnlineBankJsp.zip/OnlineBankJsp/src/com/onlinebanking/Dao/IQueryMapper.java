package com.onlinebanking.Dao;

public interface IQueryMapper {
	public static final String GET_ACCOUNTS = "SELECT account_no,user_id,login_password FROM user_table WHERE user_id=?";
	public static final String GET_EMAIL="SELECT EMAIL FROM CUSTOMERS WHERE ACCOUNT_NO=?";
	public static final String UPDATE_EMAIL="UPDATE CUSTOMERS SET EMAIL=? WHERE ACCOUNT_NO=? AND EMAIL=?";
	public static final String GET_ADDRESS="SELECT ADDRESS FROM CUSTOMERS WHERE ACCOUNT_NO=?";
	public static final String UPDATE_ADDRESS="UPDATE CUSTOMERS SET ADDRESS=? WHERE ACCOUNT_NO=? AND ADDRESS=?";
	public static final String RAISECHECKBOOK="INSERT INTO SERVICE_TRACKER VALUES(?,?,?,SYSDATE,?)";
	public static final String SER_SEQ_ID="SELECT SER_SEQ_ID.NEXTVAL FROM DUAL";
	public static final String SERVICE_REQUEST_DETAILS="SELECT * FROM SERVICE_TRACKER WHERE SERVICE_ID=?";
}
