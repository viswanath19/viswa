package com.capgemini.onlineBanking.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.onlineBanking.Util.RechargeDBConnection;

public class UserLoginDB implements IUserLogin {

	@Override
	public boolean LoginValidation(String userName, String pwd) {
		String password=null;
		boolean result = false;
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		  
		//step2 create  the connection object  
		Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
		  
		//step3 create the statement object  
		Statement stmt=con.createStatement();  
		  
		//step4 execute query  
		ResultSet rs=stmt.executeQuery("select password from bankusers where username='"+userName+"'"); 
		if(rs!=null){
			while(rs.next()){
				password=rs.getString(1);
				//System.out.println(password);
				//System.out.println(pwd);
				if(password.equals(pwd)){
					result=true;
					//System.out.println(result);
				}
				else{
					result=false;
					//System.out.println(result);
				}
				//sb.append(planname+"      "+Integer.toString(amount)+"\n");
				//System.out.println(details);
				
			}
		}
		//step5 close the connection object  
		con.close();  
		  
		}catch(Exception e){ 
			//msg=e.getMessage();
		}

		return result;
	}

	@Override
	public boolean getRegistered(String userName, String pwd, long mobile, long accountno, String email) throws ClassNotFoundException, SQLException, IOException {
		Class.forName("oracle.jdbc.driver.OracleDriver");   
		//step2 create  the connection object  
		Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
		String s1="insert into bankusers values(?,?,?,?,?)";
		PreparedStatement s=con.prepareStatement(s1);
		//String s2="select rec_seq.nextval from dual";
		java.sql.Statement sw=con.createStatement();
		//ResultSet r1=sw.executeQuery(s2);
		//s.executeUpdate();
		s=con.prepareStatement(s1);
		//s.setInt(1,val);
		s.setString(1,userName);
		s.setString(2,pwd);
		s.setLong(3, mobile);
		s.setLong(4, accountno);
		//s.setString(4,status);
		s.setString(5,email);
		//s.setInt(6,amount);
		s.executeUpdate();
		
		return false;
	}

}
