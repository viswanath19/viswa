package com.capgemini.onlineBanking.dao;

import java.io.IOException;
import java.sql.SQLException;

public interface IUserLogin {

	boolean LoginValidation(String userName, String pwd);

	boolean getRegistered(String userName, String pwd, long mobile, long accountno, String email) throws ClassNotFoundException, SQLException, IOException;
	

}
