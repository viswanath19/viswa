package com.capgemini.onlineBanking.service;

import java.io.IOException;
import java.sql.SQLException;

import com.capgemini.onlineBanking.bean.UserAccountBean;

public interface IUserAccount {
	boolean isValidUser(String userName, String pwd);

	boolean getRegistered(String userName, String pwd, long mobile, long accountno, String email) throws ClassNotFoundException, SQLException, IOException;
}
