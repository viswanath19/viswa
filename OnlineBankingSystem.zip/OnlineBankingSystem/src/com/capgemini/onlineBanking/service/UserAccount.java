package com.capgemini.onlineBanking.service;

import java.io.IOException;
import java.sql.SQLException;

import com.capgemini.onlineBanking.dao.IUserLogin;
import com.capgemini.onlineBanking.dao.UserLoginDB;

public class UserAccount implements IUserAccount{

	@Override
	public boolean isValidUser(String userName, String pwd) {
		
		boolean result;
		IUserLogin il=new UserLoginDB();
		result=il.LoginValidation(userName,pwd);
		
		return result;
	}

	@Override
	public boolean getRegistered(String userName, String pwd, long mobile, long accountno, String email) throws ClassNotFoundException, SQLException, IOException {
		boolean result;
		IUserLogin il=new UserLoginDB();
		result=il.getRegistered(userName,pwd,mobile,accountno,email);
		return false;
	}

}
