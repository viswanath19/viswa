package com.capgemini.cabs.exception;

public class CabsException extends Exception{
	public CabsException(String msg){
		super(msg);
	}

}
