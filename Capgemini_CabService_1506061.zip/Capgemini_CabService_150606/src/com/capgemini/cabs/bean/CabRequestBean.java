package com.capgemini.cabs.bean;

public class CabRequestBean {
	private String customerName;
	private long phoneNumber;
	private String dateOfRequest;
	private String requestStatus;
	private String cabNumber;
	private long requestId;
	private String pickupAddress;
	private long pincode;
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getDateOfRequest() {
		return dateOfRequest;
	}
	public void setDateOfRequest(String dateOfRequest) {
		this.dateOfRequest = dateOfRequest;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	public String getCabNumber() {
		return cabNumber;
	}
	public void setCabNumber(String cabNumber) {
		this.cabNumber = cabNumber;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getPickupAddress() {
		return pickupAddress;
	}
	public void setPickupAddress(String pickupAddress) {
		this.pickupAddress = pickupAddress;
	}
	public long getPincode() {
		return pincode;
	}
	public void setPincode(long pincode) {
		this.pincode = pincode;
	}
	public CabRequestBean(String customerName, long phoneNumber,
			String dateOfRequest, String requestStatus, String cabNumber,
			long requestId, String pickupAddress, long pincode) {
		this.customerName = customerName;
		this.phoneNumber = phoneNumber;
		this.dateOfRequest = dateOfRequest;
		this.requestStatus = requestStatus;
		this.cabNumber = cabNumber;
		this.requestId = requestId;
		this.pickupAddress = pickupAddress;
		this.pincode = pincode;
	}
	public CabRequestBean(){
		
	}
	

}
