package com.capgemini.cabs.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.cabs.exception.CabsException;
import com.capgemini.cabs.util.CabServiceDBConnection;
//import com.capgemini.recharge.dao.ISqlFinalQueries;
//import com.capgemini.recharge.util.RechargeDBConnection;

public class CabRequestDao implements ICabRequestDao{
	Logger logger=Logger.getRootLogger();
	public CabRequestDao()
	{
	//System.out.println("hello");
	PropertyConfigurator.configure("resources//log4j.properties");
	}

	@Override
	public void createTable() throws IOException, SQLException, ClassNotFoundException, CabsException {
		try{  
			
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			 
			Connection con=CabServiceDBConnection.getConnection();  
			  
			  
			
			Statement statement=con.createStatement();  
			String creation=IQueryMapper.tablecreation;
			statement.executeUpdate(creation);
			  
			
			
			
			con.close();  
			  
			}catch(SQLException e){ 
				throw new CabsException("Database Connectivity Error");
			}
		    catch(IOException e){
		    	throw new CabsException("Database Connectivity Error");
		    }
			catch(ClassNotFoundException c){
				throw new CabsException("Driver Error");
			}
		
	}

	@Override
	public long createRequest(String customerName, long phone,
			String pickupAddress, long pinCode,String validatePin,String status) throws IOException, SQLException, CabsException {
		
		Connection conn=CabServiceDBConnection.getConnection();//DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");
		String s1=IQueryMapper.insertRequestDetails;
		PreparedStatement s=conn.prepareStatement(s1);
		String s2=IQueryMapper.requestid;
		java.sql.Statement sw=conn.createStatement();
		ResultSet resultset=sw.executeQuery(s2);
		long val=0;
		if(resultset.next())
		{
			logger.info("request id fetched");
			val=resultset.getInt(1);
		}
		long temp=val;
		String date=null;
		String getDate="select sysdate from dual";
		ResultSet rs=sw.executeQuery(getDate);
		while(rs.next()){
			date=rs.getString(1);
		}
		//System.out.println(val);
		//s.executeUpdate();
		s=conn.prepareStatement(s1);
		s.setLong(1,val);
		s.setString(2,customerName);
		s.setLong(3, phone);
		s.setString(4, date);
		s.setString(5,status);
		s.setString(6,validatePin);
		s.setString(7,pickupAddress);
		s.setLong(8, pinCode);
		s.executeUpdate();
		logger.info("values stored succesfully");
		return val;
	}

	@Override
	public String[] createstatus(long requestid) throws CabsException {
		String name;
		String status;
		String cab_number;
		long req_id = 0;
		String arr[]=new String[3];
		StringBuilder sb=new StringBuilder();
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		  
		 
		Connection con=CabServiceDBConnection.getConnection();  
		  
		  
		
		Statement statement=con.createStatement();  
		ResultSet rs=statement.executeQuery("select customer_name,request_status,cab_number,request_id from cab_request where request_id='"+requestid+"'");
		if(rs!=null){
			while(rs.next()){
				name=rs.getString(1);
				status=rs.getString(2);
				cab_number=rs.getString(3);
				req_id=rs.getLong(4);
				logger.info("details fetched succesfully");
				arr[0]=name;
				arr[1]=status;
				arr[2]=cab_number;
				sb.append(name+"    "+status+"    "+cab_number);
			}
		}
		
		if(req_id==0){
			throw new CabsException("Details not found for requested id");
		}
		
		
		
		
		con.close();  
		  
		}catch(SQLException e){ 
			logger.error("Exception occured");
			throw new CabsException("Database Connection Error");
			
		}
	    catch(IOException e){
	    	logger.error("Exception occured");
	    	throw new CabsException("Database prperties file doesn't get input");
	    	
	    }
		catch(ClassNotFoundException c){
			logger.error("Exception occured");
			throw new CabsException("Driver Does not exists ");
		}
		return arr;
		
	}
}
