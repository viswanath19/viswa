package com.capgemini.cabs.dao;

import java.io.IOException;
import java.sql.SQLException;

import com.capgemini.cabs.exception.CabsException;

public interface ICabRequestDao {
	public void createTable() throws IOException, SQLException, ClassNotFoundException,CabsException;

	public long createRequest(String customerName, long phone,
			String pickupAddress, long pinCode,String validatePin,String status) throws IOException, SQLException,CabsException;

	public String[] createstatus(long requestid) throws CabsException;
}
