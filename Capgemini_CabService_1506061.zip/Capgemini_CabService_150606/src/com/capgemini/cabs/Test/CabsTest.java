package com.capgemini.cabs.Test;

import java.io.IOException;
import java.sql.SQLException;

import com.capgemini.cabs.bean.*;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.cabs.bean.CabRequestBean;
import com.capgemini.cabs.dao.CabRequestDao;
import com.capgemini.cabs.exception.CabsException;
import com.capgemini.cabs.service.CabService;

public class CabsTest{
	CabRequestDao crd=null;
	CabRequestBean crb=null;
	CabService d=null;
	long mobileno=7894561230L;
	@Before
	public void Initialize()
	{
		crd=new CabRequestDao();
		crb=new CabRequestBean();
		d=new CabService();
	}
	
	@Test
	public void validateName(){
		String result=d.validateName("sharma");
		crb.setCustomerName(result);
		assertEquals("true",crb.getCustomerName());
		
	}
	@Test
	public void validatePinCode(){
		String result=d.validatePin(400056);
		crb.setCabNumber(result);
		assertEquals("true",crb.getCabNumber());
		
	}
	@Test
	public void validateCode(){
		String result=d.validatePin(400096);
		crb.setCabNumber(result);
		assertEquals("MH VS 2345",crb.getCabNumber());
		
	}
	/*@Test
	public void testAddUserDetails1() throws InvalidRecharge
	{
		rb.setUserName("Yash");
		rb.setUserMobileNum("9700036222");
		rb.setPlanName("Rc150");
		rech.retrieveAmount("Rc150");
		rech.addUserDetails(rb);
		assertEquals("Success",rb.getStatus());
	}
	@Test
	public void testRetrieveUserDetails() throws InvalidRecharge
	{
		assertSame(false,rech.retrieveUserDetails("100000",rb));
}
	@Test
	public void testRetrieveUserDetails1() throws InvalidRecharge
	{
		assertNotSame(false,rech.retrieveUserDetails("1000009",rb));
	}
	*/
	
}
