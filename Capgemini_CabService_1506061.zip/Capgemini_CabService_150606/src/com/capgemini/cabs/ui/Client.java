package com.capgemini.cabs.ui;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.cabs.exception.CabsException;
import com.capgemini.cabs.service.CabService;
import com.capgemini.cabs.service.ICabService;

public class Client {
	static Logger logger=Logger.getRootLogger();
	public static void main(String[] args){
		
		PropertyConfigurator.configure("resources//log4j.properties");
		do{
		System.out.println("Welcome to Swift Cab Services");
		System.out.println("Choose your option 1.Raise cab Request 2.View Cab Request Status 3.Exit");
		Scanner scanner=new Scanner(System.in);
		int choice=scanner.nextInt();
		ICabService icabservice=new CabService();
		if(choice==1){
			String validatename;
			String validatePhone;
			String validatePin;
			String customerName;
			String pickupAddress;
			String status;
			long pinCode;
			long phone;
			do{
			System.out.println("Enter the name of the customer: ");
			customerName=scanner.next();
			validatename=icabservice.validateName(customerName);
			if(validatename!="true"){
				System.out.println(validatename);
			}
			}while(validatename!="true");
			do{
			System.out.println("Enter customer phone number: ");
			String phoneNumber=scanner.next();
		    phone=Long.valueOf(phoneNumber);
			validatePhone=icabservice.validatePhone(phoneNumber);
			if(validatePhone!="true"){
				System.out.println(validatePhone);
			}
			}while(validatePhone!="true");
			System.out.println("Enter Pick up Address: ");
			pickupAddress=scanner.next();
			do{
			System.out.println("Enter Pin Code: ");
			pinCode=scanner.nextLong();
			validatePin=icabservice.validatePin(pinCode);
			}while(validatePin==null);
			status="success";
			try{
			long requestid = icabservice.createRequest(customerName,phone,pickupAddress,pinCode,validatePin,status);
			System.out.println("Your Cab Request-id is:"+requestid);
			}
			catch(SQLException e){
				System.out.println(e.getMessage());
			}
			catch(IOException e){
				System.out.println(e.getMessage());
				
			}
			catch(CabsException e){
				System.out.println(e.getMessage());
			}
			}
		else if(choice==2){
			System.out.println("Enter your request id");
			long requestid=scanner.nextLong();
			try{
			String details[]=icabservice.checkstatus(requestid);
			System.out.println("Name of Customer: "+details[0]);
			System.out.println("Request Status:  "+details[1]);
			System.out.println("Cab Number:  "+details[2]);
			}
			catch(CabsException e){
				System.out.println(e.getMessage());
			}
		}
		else if(choice==3){
			break;
		}
		}while(true);
		
		
	}
	

}
