package com.onlinebanking.Service;

import java.util.ArrayList;

import com.onlinebanking.Bean.OnlineBankingBean;
import com.onlinebanking.Exception.OnlineBankingException;

public interface IonlineBankingService {

	ArrayList<Long> validateUser(long userId, String password) throws OnlineBankingException;

	ArrayList<OnlineBankingBean> getMiniStatement(String acc_no) throws OnlineBankingException;

}
