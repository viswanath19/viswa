package com.onlinebanking.Service;

import java.util.ArrayList;

import com.onlinebanking.Bean.OnlineBankingBean;
import com.onlinebanking.Dao.IonlineBankingDao;
import com.onlinebanking.Dao.OnlineBankingDao;
import com.onlinebanking.Exception.OnlineBankingException;

public class OnlineBankingService implements IonlineBankingService{

	@Override
	public ArrayList<Long> validateUser(long userId, String password) throws OnlineBankingException{
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<Long> accounts=ibd.validateUser(userId,password);
		return accounts;
	}

	@Override
	public ArrayList<OnlineBankingBean> getMiniStatement(String acc_no) throws OnlineBankingException {
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<OnlineBankingBean> miniStatement=ibd.getMiniStatement(acc_no);
		return miniStatement;
	}

}
