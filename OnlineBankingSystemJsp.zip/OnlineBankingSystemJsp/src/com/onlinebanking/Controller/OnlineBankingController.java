package com.onlinebanking.Controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.onlinebanking.Bean.OnlineBankingBean;
import com.onlinebanking.Exception.OnlineBankingException;
import com.onlinebanking.Service.IonlineBankingService;
import com.onlinebanking.Service.OnlineBankingService;

/**
 * Servlet implementation class OnlineBankingController
 */
@WebServlet("/OnlineBankingController")
public class OnlineBankingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OnlineBankingController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd=null;
		String operation=request.getParameter("action");
		HttpSession session=request.getSession(true);
		IonlineBankingService ibs=new OnlineBankingService();
		ArrayList<Long> accounts=new ArrayList<Long>();
		if(operation!=null&&operation.equalsIgnoreCase("loginValidation")){
			long userId=Long.parseLong(request.getParameter("userId"));
			String password=request.getParameter("password");
			try{
				accounts=ibs.validateUser(userId,password);
				session.setAttribute("accounts",accounts);
				System.out.println(accounts);
				rd=request.getRequestDispatcher("/home.jsp");
				rd.include(request, response);
			}
			catch(OnlineBankingException e){
				
			}
		}
		if(operation!=null&&operation.equalsIgnoreCase("FetchAccounts")){
			String accountDetails=request.getParameter("accounts").toString().replace("[", "").replace("]", "");
			List<String> myList = new ArrayList<String>(Arrays.asList(accountDetails.split(",")));
			System.out.println(accountDetails);
			request.setAttribute("accountDetails", myList);
			rd=request.getRequestDispatcher("/FetchAccounts.jsp");
			rd.include(request, response);
		}
		if(operation!=null&&operation.equals("viewMiniStatement")){
			String acc_no=request.getParameter("accountno");
			try {
				ArrayList<OnlineBankingBean> miniStatement=ibs.getMiniStatement(acc_no);
				System.out.println(miniStatement);
				request.setAttribute("miniStatement", miniStatement);
				rd=request.getRequestDispatcher("/ViewMiniStatement.jsp");
				rd.forward(request, response);
			} catch (OnlineBankingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
}
}