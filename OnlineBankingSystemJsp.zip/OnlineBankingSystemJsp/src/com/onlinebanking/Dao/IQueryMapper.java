package com.onlinebanking.Dao;

public interface IQueryMapper {
	String miniStatement="select account_no,trans_amount,transaction_id,transaction_date from transactions where account_no=? and rownum<=5";
}
