package com.onlinebanking.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.onlinebanking.Bean.OnlineBankingBean;
import com.onlinebanking.Exception.OnlineBankingException;
import com.onlinebanking.Util.DBUtil;

public class OnlineBankingDao implements IonlineBankingDao{

	@Override
	public ArrayList<Long> validateUser(long userId, String password) throws OnlineBankingException{
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		long user_id=0;
		String pwd=null;
		long account_no=0;
		ArrayList<Long> accounts=new ArrayList<Long>();
		try{
			con=DBUtil.obtainConnection();
			stmt=con.createStatement();
			rs=stmt.executeQuery("select account_no,user_id,login_password from user_table where user_id='"+userId+"' and login_password='"+password+"'");
			if(rs!=null){
				while(rs.next()){
					user_id=rs.getLong(2);
					pwd=rs.getString(3);
					account_no=rs.getLong(1);
					accounts.add(account_no);
				}
			}
			if(user_id!=userId||!password.equals(pwd)){
				throw new OnlineBankingException("Invalid Credentials");
			}
			
		}
		catch(OnlineBankingException e){
			throw new OnlineBankingException("details not fetched");
		}
		catch(Exception e){
			throw new OnlineBankingException("DataBase error");
		}
		return accounts;
	}

	@Override
	public ArrayList<OnlineBankingBean> getMiniStatement(String acc_no) throws OnlineBankingException {
		String trans_details=null;
		long accountno = 0;
		long trans_id=0;
		int count=0;
		long amount;
		StringBuilder sb=new StringBuilder();
		ArrayList<OnlineBankingBean> miniStatement = new ArrayList<OnlineBankingBean>();
		try{
		/*Class.forName("oracle.jdbc.driver.OracleDriver");   
		//step2 create  the connection object  
		Connection con=DBUtil.obtainConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select count(*) from transactions where account_no='"+acc_no+"'");
		if(rs!=null){
			while(rs.next()){
				count=rs.getInt(1);
			}
		}
		if(count==0){
			throw new OnlineBankingException("No transactions available");
		}*/ 
		//step4 execute query  
		Connection con=DBUtil.obtainConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
		Statement stmt=con.createStatement();  
		PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.miniStatement);
		long account_no=Long.parseLong(acc_no);
		pmstmt.setLong(1, account_no);
		System.out.println("hello");
		ResultSet rs=pmstmt.executeQuery();
		
		System.out.println("hello");
		
		if(rs!=null){
			while(rs.next()){
				OnlineBankingBean b=new OnlineBankingBean();
				//account=rs.getLong(1);
				trans_details=rs.getString(4);
				System.out.println(trans_details);
				amount=rs.getLong(2);
				System.out.println(amount);
				accountno=rs.getLong(1);
				System.out.println(accountno);
				trans_id=rs.getLong(3);
				System.out.println(trans_id);
				//String accountNo=Long.toString(accountno);
				//String trans_amount=Long.toString(amount);
				//String transId=Long.toString(trans_id);
				//System.out.println(accountNo+"       "+trans_amount+"         "+transId+"        "+trans_details);
				b.setAccountNo(accountno);
				b.setTransactionId(trans_id);
				b.setTransactionAmount(amount);
				b.setTransactionDate(trans_details);
				miniStatement.add(b);
				
				//sb.append(trans_id+"       "+accountno+"           "+amount+"          "+trans_details);
			}
		}
		  
	}
		catch(Exception e){
			//throw new OnlineBankingException("Failed in database Connectivity");
			//System.out.println(e.getMessage()+" hello");
			e.printStackTrace();
		}
// TODO Auto-generated method stub
		return miniStatement;
	}

}
