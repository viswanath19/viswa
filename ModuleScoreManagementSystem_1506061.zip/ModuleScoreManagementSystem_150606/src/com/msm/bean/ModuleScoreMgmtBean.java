package com.msm.bean;

public class ModuleScoreMgmtBean {
	private long traineeId;
	private String moduleName;
	private double mpt;
	private double mtt;
	private double assignment;
	private double total;
	private int grade;
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public long getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(long traineeId) {
		this.traineeId = traineeId;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public double getMpt() {
		return mpt;
	}
	public void setMpt(double mpt) {
		this.mpt = mpt;
	}
	public double getMtt() {
		return mtt;
	}
	public void setMtt(double mtt) {
		this.mtt = mtt;
	}
	public double getAssignment() {
		return assignment;
	}
	public void setAssignment(double assignment) {
		this.assignment = assignment;
	}

}
