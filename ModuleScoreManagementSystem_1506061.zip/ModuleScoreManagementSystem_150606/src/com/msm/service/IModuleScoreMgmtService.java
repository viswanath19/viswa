package com.msm.service;

import java.util.ArrayList;

import com.msm.bean.ModuleScoreMgmtBean;
import com.msm.exception.ModuleScoreMgmtException;

public interface IModuleScoreMgmtService {

	ArrayList<Long> getTraineeId() throws ModuleScoreMgmtException;

	ArrayList<ModuleScoreMgmtBean> registerScores(ModuleScoreMgmtBean msmb) throws ModuleScoreMgmtException;

}
