package com.msm.service;

import java.util.ArrayList;

import com.msm.bean.ModuleScoreMgmtBean;
import com.msm.dao.IModuleScoreMgmtDao;
import com.msm.dao.ModuleScoreMgmtDao;
import com.msm.exception.ModuleScoreMgmtException;

public class ModuleScoreMgmtService implements IModuleScoreMgmtService{

	@Override
	public ArrayList<Long> getTraineeId() throws ModuleScoreMgmtException{
		IModuleScoreMgmtDao imsmd=new ModuleScoreMgmtDao();
		ArrayList<Long> trainees=new ArrayList<Long>(20);
		trainees=imsmd.getTrainees();
		return trainees;
	}

	@Override
	public ArrayList<ModuleScoreMgmtBean> registerScores(
			ModuleScoreMgmtBean msmb) throws ModuleScoreMgmtException {
		ArrayList<ModuleScoreMgmtBean> result=new ArrayList<ModuleScoreMgmtBean>();
		IModuleScoreMgmtDao imsmd=new ModuleScoreMgmtDao();
		result=imsmd.registerScores(msmb);
		return result;
	}

}
