package com.msm.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.msm.bean.ModuleScoreMgmtBean;
import com.msm.exception.ModuleScoreMgmtException;
import com.msm.service.IModuleScoreMgmtService;
import com.msm.service.ModuleScoreMgmtService;

/**
 * Servlet implementation class ModuleScoreManagementController
 */
@WebServlet("/ModuleScoreManagementController")
public class ModuleScoreManagementController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModuleScoreManagementController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd=null;
		String operation=request.getParameter("action");
		IModuleScoreMgmtService imsms=new ModuleScoreMgmtService();
		if(operation!=null&&operation.equalsIgnoreCase("addAssessmentDetails")){
			ArrayList<Long> traineesId=new ArrayList<Long>(20);
			try{
			traineesId=imsms.getTraineeId();
			request.setAttribute("traineeId", traineesId);
			rd=request.getRequestDispatcher("/AddAssessmentDetails.jsp");
			rd.forward(request, response);
			}
			catch(ModuleScoreMgmtException e){
				request.setAttribute("error", e.getMessage());
				rd=request.getRequestDispatcher("/error.jsp");
				rd.forward(request, response);
			}
		}
		if(operation!=null&&operation.equalsIgnoreCase("addAssessmentMarks")){
			long traineeId=Long.parseLong(request.getParameter("traineeId"));
			String moduleName=request.getParameter("module");
			double mpt=Double.parseDouble(request.getParameter("mpt"));
			double mtt=Double.parseDouble(request.getParameter("mtt"));
			double assignment=Double.parseDouble(request.getParameter("assignment"));
			double total;
			int grade=0;
			mpt=(mpt*0.7);
			mtt=(mtt*0.15);
			assignment=(assignment*0.15);
			total=mpt+mtt+assignment;
			
			if(total>=0&&total<50){
				grade=0;
			}
			else if(total>=50&&total<60){
				grade=1;
			}
			else if(total>=60&&total<70){
				grade=2;
			}
			else if(total>=70&&total<80){
				grade=3;
			}
			else if(total>=80&&total<90){
				grade=4;
			}
			else if(total>=90&&total<=100){
				grade=5;	
			}
			
			ArrayList<ModuleScoreMgmtBean> result=new ArrayList<ModuleScoreMgmtBean>();
			try{
				ModuleScoreMgmtBean msmb=new ModuleScoreMgmtBean();
				msmb.setTraineeId(traineeId);
				msmb.setModuleName(moduleName);
				msmb.setMtt(mtt);
				msmb.setMpt(mpt);
				msmb.setAssignment(assignment);
				msmb.setTotal(total);
				msmb.setGrade(grade);
				result=imsms.registerScores(msmb);
				request.setAttribute("storedDetails", result);
				System.out.println(result);
				rd=request.getRequestDispatcher("/ModuleScore.jsp");
				rd.forward(request, response);
			}
			catch(ModuleScoreMgmtException e){
				request.setAttribute("error", e.getMessage());
				rd=request.getRequestDispatcher("/AddAssessmentDetails.jsp");
				rd.forward(request, response);
			}
		}
	}

}
