package com.msm.exception;

public class ModuleScoreMgmtException extends Exception{
	public ModuleScoreMgmtException(String msg){
		super(msg);
	}
}
