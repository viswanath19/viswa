package com.msm.dao;

import java.util.ArrayList;

import com.msm.bean.ModuleScoreMgmtBean;
import com.msm.exception.ModuleScoreMgmtException;

public interface IModuleScoreMgmtDao {

	ArrayList<Long> getTrainees() throws ModuleScoreMgmtException;

	ArrayList<ModuleScoreMgmtBean> registerScores(ModuleScoreMgmtBean msmb) throws ModuleScoreMgmtException;

}
