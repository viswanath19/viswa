package com.msm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.msm.bean.ModuleScoreMgmtBean;
import com.msm.exception.ModuleScoreMgmtException;
import com.msm.util.DBUtil;

public class ModuleScoreMgmtDao implements IModuleScoreMgmtDao{

	@Override
	public ArrayList<Long> getTrainees() throws ModuleScoreMgmtException {
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		ArrayList<Long> trainees=new ArrayList<Long>(20);
		try{
			con=DBUtil.obtainConnection();
			stmt=con.createStatement();
			rs=stmt.executeQuery(IQueryMapper.TRAINEEID);
			if(rs!=null){
				while(rs.next()){
					trainees.add(rs.getLong(1));
				}
			}
			
			
		}
		catch(SQLException e){
			throw new ModuleScoreMgmtException("database interaction error");
		}
		return trainees;
	}

	@Override
	public ArrayList<ModuleScoreMgmtBean> registerScores(
			ModuleScoreMgmtBean msmb) throws ModuleScoreMgmtException {
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		ArrayList<ModuleScoreMgmtBean> result=new ArrayList<ModuleScoreMgmtBean>();
		try{
			con=DBUtil.obtainConnection();
			stmt=con.createStatement();
			long trainee_id=0;
			String module_name=null;
			rs=stmt.executeQuery("select distinct trainee_id,module_name from assessmentScore");
			if(rs!=null){
				while(rs.next()){
					module_name=rs.getString(2);
					trainee_id=rs.getLong(1);
				}
			}
			if(module_name.equals(msmb.getModuleName())&&trainee_id==msmb.getTraineeId()){
				throw new ModuleScoreMgmtException("Records already exist");
			}
			else{
			String insertQuery=IQueryMapper.ASSESSMENTDETAILS;
			PreparedStatement pmstmt=con.prepareStatement(insertQuery);
			pmstmt.setLong(1, msmb.getTraineeId());
			pmstmt.setString(2, msmb.getModuleName());
			pmstmt.setDouble(3, msmb.getMpt());
			pmstmt.setDouble(4, msmb.getMtt());
			pmstmt.setDouble(5, msmb.getAssignment());
			pmstmt.setDouble(6, msmb.getTotal());
			pmstmt.setInt(7, msmb.getGrade());
			int records=pmstmt.executeUpdate();
			//System.out.println("hello");
			if(records>0){
				String retriveQuery=IQueryMapper.UPDATEDASSESSMENTDETAILS;
				pmstmt=con.prepareStatement(retriveQuery);
				pmstmt.setString(1, msmb.getModuleName());
				pmstmt.setLong(2, msmb.getTraineeId());
				pmstmt.setInt(3,msmb.getGrade());
				pmstmt.setDouble(4, msmb.getTotal());
				rs=pmstmt.executeQuery();
				ModuleScoreMgmtBean msmg=new ModuleScoreMgmtBean();
				if(rs!=null){
					while(rs.next()){
						
						msmg.setTraineeId(rs.getLong(1));
						msmg.setModuleName(rs.getString(2));
						msmg.setTotal(rs.getDouble(3));
						msmg.setGrade(rs.getInt(4));
						result.add(msmg);
						
					}
				}
				
			}
			else{
				throw new ModuleScoreMgmtException("Records not inserted");
			}
			}
		}
		catch(SQLException e){
			throw new ModuleScoreMgmtException("Error");
		}
		return result;
	}

}
