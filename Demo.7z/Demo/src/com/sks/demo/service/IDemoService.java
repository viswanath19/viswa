package com.sks.demo.service;

import com.sks.demo.bean.UserDetails;

public interface IDemoService 
{
	public UserDetails getEmpDetails(int empid);
}
