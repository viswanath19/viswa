package com.sks.demo.service;

import com.sks.demo.bean.UserDetails;
import com.sks.demo.dao.DemoDaoImpl;

public class DemoServiceImpl implements IDemoService 
{

	@Override
	public UserDetails getEmpDetails(int empid) 
	{
		UserDetails det=new UserDetails();
		DemoDaoImpl obj=new DemoDaoImpl();
		det=obj.getEmpDetails(empid);
		return det;
	}
	
}
