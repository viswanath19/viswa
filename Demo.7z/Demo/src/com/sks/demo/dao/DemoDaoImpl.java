package com.sks.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.sks.demo.bean.UserDetails;

public class DemoDaoImpl implements IDemoDao
{
	@Override
	public UserDetails getEmpDetails(int empid) 
	{
		String empname=null;
		int sal;
		String dept;
		UserDetails det=new UserDetails();
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle"); 
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select empname,salary,dept from employee where empid='"+empid+"'");
			//PreparedStatement preparedStatement=con.prepareStatement("select empname from employee where empid='"+empid+"'");
			//preparedStatement.setInt(1, det.getEmpid());
			//ResultSet resultSet=preparedStatement.executeQuery();
			while(rs.next())
			{
				empname=rs.getString(1);
				sal=rs.getInt(2);
				dept=rs.getString(3);
				det.setEmpname(empname);
				det.setSal(sal);
				det.setDept(dept);
			}
		}
		catch(Exception e)
		{ 
			System.out.println(e);
		} 
		//System.out.println(empname);
		//System.out.println(det.getDept());
		return det;
	}
}
