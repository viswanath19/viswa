package com.sks.demo.dao;

import com.sks.demo.bean.UserDetails;

public interface IDemoDao 
{
	public UserDetails getEmpDetails(int empid);
}
