package com.sks.demo.ui;

import java.util.Scanner;

import com.sks.demo.bean.UserDetails;
import com.sks.demo.service.DemoServiceImpl;

public class Main 
{
	public static void main(String[] args) 
	{
		UserDetails det=new UserDetails();
		int ch;
		System.out.println("1.View single details 2.View all details 3.Exit");
		System.out.println("Enter your choice: ");
		Scanner sc=new Scanner(System.in);
		ch=sc.nextInt();
		do
		{
			switch (ch)
			{
			case 1:
				System.out.println("Enter employee ID:");
				Scanner sc1=new Scanner(System.in);
				int emid=sc1.nextInt();
				det.setEmpid(emid);
				int empid=det.getEmpid();
				DemoServiceImpl obj=new DemoServiceImpl();
				det=obj.getEmpDetails(empid);
				System.out.println(det.getEmpname()+" "+det.getSal()+" "+det.getDept());
				
				break;

			default:
				break;
			}
		}while(ch!=2);
	}
}
